package com.example.dell.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button DatosPersonales;
    Button FormacionAcademica;
    Button ExperienciaProfesional;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatosPersonales = (Button)findViewById(R.id.button1);
        FormacionAcademica = (Button)findViewById(R.id.boton2);
        ExperienciaProfesional = (Button)findViewById(R.id.boton3);


        DatosPersonales.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent DatosPersonales = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(DatosPersonales);
            }
        });

        FormacionAcademica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent FormacionAcademica = new Intent(MainActivity.this, Main3Activity.class);
                startActivity(FormacionAcademica);
            }
        });

        ExperienciaProfesional.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ExperienciaProfesional = new Intent(MainActivity.this, Main4Activity.class);
                startActivity(ExperienciaProfesional);
            }
        });

    }
}
